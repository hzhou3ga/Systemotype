c	smaller step
c	modified tree_cons to fast, removed  some repeat partitions  
c	maxit=5551-> 2000 
c       maxpr=5 from 2500 ( not used ) 

	implicit none
        integer n_dep,n_var,n_data,my_data,my_var,n_nod
        integer i,j,k,l,m,n,l1,l2,l0,j0,id,level,ipr,maxali
     &  ,maxalilen,maxpr,maxit
        parameter(n_dep=6,n_data=300,n_var=5000,n_nod=1500,level=2)
        parameter(maxpr=5,maxalilen=200,maxit=2000)
        integer nodlst(n_nod,5),nod_num,nod_num0,dat(n_nod,n_data)
     &  ,my_data2,k1,k2,iter,myit,iter2,i_restart,iter0,myit0
        INTEGER*4 ISEED
        real*8 y(n_data),x(n_data,n_var),s0,s1,s2,yav1,yav2,yout,
     &  g0,g1,thr,threshold(n_nod,2),x1,x2,yav0,xinp(n_var)
     &  ,ffuv(4,4,maxpr,maxalilen),y2(n_data)
     &  ,step,stepneg(3,3),astep(maxit)
        integer mytree(4,4,maxit,n_nod,5),mynodnum(4,4,maxit)
        real*8  mythre(4,4,maxit,n_nod,2)
        common /treedat/mythre,mytree,mynodnum
        common /seed/iseed

        character flst*170,base*70,fsec*70,fali*70,flst2*170
        common /myinp/step,flst,base,fsec,fali,myit
        data stepneg/9*0.d0/


c	1-M 2-I_s: 3-I_t:4-null       
          do i=1,4  ! u I-1  position
             do j=1,3  ! v 	I  position
              do l=1,maxit
              mynodnum(i,j,l)=0
              enddo
              do l=1,maxpr
               do k=1,maxalilen
               ffuv(i,j,l,k)=0
               enddo
              enddo
             enddo
          enddo
          iseed=123
          step=0.1


            read(*,*) myit,i_restart,step,my_var
            read(*,'(70a)') base
            read(*,*) flst
            if(i_restart.gt.0) then
            read(*,*) flst2
            endif 
            iter0=1
            
        if(i_restart.gt.0) then

        open(unit=60,file=flst2,status='old')
          read(60,*) myit0,step,my_var
          i=1
          j=1
              do iter=1,myit0
            read(60,*) mynodnum(i,j,iter)
             do k=1,mynodnum(i,j,iter)
                read(60,*) (mytree(i,j,iter,k,l),l=1,5),
     &          mythre(i,j,iter,k,1),mythre(i,j,iter,k,2)
             enddo


              enddo  ! iter
          close(60)
          
         if(i_restart.eq.1) then
         if(myit.lt.myit0) myit0=myit
         call generateexample(ffuv,1,1,myit0,x,y,y2,my_data,my_var,1)
          stop
         else
          iter0=myit0+1
         endif 

        endif 


        i=1
        j=1
        do iter=iter0,myit
	call generateexample(ffuv,i,j,iter,x,y,y2,my_data,my_var,-1)
        write(*,*) 'constr tree ',i,j,' : ',iter,my_var,my_data
	call tree_cons(my_data,my_var,x,y,y2,nodlst,nod_num,threshold)
c        write(*,*) 'constr tree final ',i,j,' : ',iter 

             mynodnum(i,j,iter)=nod_num
             do k=1,nod_num
                do l=1,5
                mytree(i,j,iter,k,l)=nodlst(k,l)
                enddo
                mythre(i,j,iter,k,1)=threshold(k,1)
                mythre(i,j,iter,k,2)=threshold(k,2)
             enddo


c       output model 
         open(unit=60,file='modele.out',status='unknown')
          write(60,*) iter,step,my_var
              do iter2=1,iter

            write(60,*) mynodnum(i,j,iter2),i,j,iter2
             do k=1,mynodnum(i,j,iter2)
                write(60,*) (mytree(i,j,iter2,k,l),l=1,5),
     &          mythre(i,j,iter2,k,1),mythre(i,j,iter2,k,2)
             enddo

              enddo

          close(60)

        enddo

	stop

         end

c	##############################
	subroutine generateexample(ffuv,iu,jv,iter,
     &  x,y,y2,my_data,my_var,iup)
        parameter(n_dep=6,n_data=300,n_var=5000,n_nod=1500)
       parameter (maxpr=5,maxalilen=200,maxres=800,maxp=500,ntyp=20)
        integer align(maxpr,maxalilen,4),numpair,pairnamlen(maxpr,2)
     &          ,alilen(maxpr,3),pairname(maxpr,2),namelen(maxpr)
     &          ,nseq(maxpr),isec(maxp,maxres),iseq(maxp,maxres)
     &          ,mylst(4,4,maxpr,maxalilen),l3,myit,mylen0(maxpr)
     & ,invmap1(maxpr,maxres),invmap2(maxpr,maxres),mylen,kseq(maxres)
     &  ,lseq(maxres),nres(maxp),align2(maxpr,maxalilen,4)
     & ,mysec(maxp,maxres),myasa(maxp,maxres),iasa(maxres),msec(maxres)
     & ,libsec(maxp,maxres),nsec(maxres),libasa(maxp,maxres)
     & ,myseq(maxp,maxres),jasa(maxres),neglst(n_data),map(20),
     &  lstpos(n_data),alilen2(maxpr,3)
     & ,ipath0(maxp,0:maxalilen,4),ipath(maxp,0:maxalilen,4)
        character aline*80,ctmp*1,resmap(20)*1,namelst(maxpr)*10,aaa*20
        real*8 prof(maxpr,0:maxalilen,n_var),ffuv(4,4,maxpr,maxalilen)
        real*8 y(n_data),y2(n_data),x(n_data,n_var),hdp(20)
        real*8 xmat(maxp,5,maxres,20),mymtx(maxres,20),pat(maxres,20)
     &   ,npflib(maxres,20),alnprf(maxres,20),aln10prf(maxres,20)
     &   ,vsec(3,3),prob,xinp(n_var),yout,probn(4,4),step,stepneg(3,3)
     &   ,x0(n_data,n_var),y0(n_data),rn
     & ,myinpt(n_data,100),conf(maxres),xo(100),myconf(maxp,maxres)
     & ,conf1(maxres),xinp0(n_var),prof2(maxpr,0:maxalilen,n_var)
     & ,bls(20,20),blse(20,20),sdm0(20,20),sdm(20,20),
     &  libalnprf(maxres,20)
     &  ,eff1,eff2,myprf1(maxres,20),myprf2(maxres,20)
     &  ,gapprf(maxp,maxres),gapp(maxres),yout2,libmtx(maxres,20),
     &  ffuv2(4,4,maxpr,maxalilen),libaln10prf(maxres,20),
     &  libconf(maxres),libgapp(maxres)
        data init/0/,negnum/0/,init1/0/
        data stepneg/9*0.d0/
        data resmap/'C','M','F','I','L','V','W','Y','A','G',
     &            'T','S','Q','N','E','D','H','R','K','P'/
        common /prf/prof,align,alilen,npair,isec,iseq,ipath0,ipath,mylen0
        common /prf2/ffuv2,prof2,align2,alilen2,npair2
        common /lst/mylst,lstpos
      data map/1,12,11,20,9,10,14,16,15,13,17,18,
     &         19,2,4,5,6,3,8,7/
      data aaa/'ARNDCQEGHILKMFPSTWYV'/


        data vsec/9*0.0/,hdp/20*0.d0/,hcut/0.d0/
        data probn/16*0.0/,sdm/400*0.0/,blse/400*0.0/
        character flst*170,base*70,fsec*70,fali*70,whole*200
        common /myinp/step,flst,base,fsec,fali,myit
        common /prf3/x0,y0,my_d0


c	
c	1-- sequence   2-- template  for each pair, also use as 2=sequence 1- template



         if(init.eq.0) then
          do i=1,4  ! u I-1  position
             do j=1,3  ! v      I  position
              do l=1,maxpr
               do k=1,maxalilen
               ffuv2(i,j,l,k)=0
               enddo
              enddo
             enddo
          enddo
            init=1
             do i=1,20
               do j=1,20
               if(aaa(i:i).eq.resmap(j)) map(i)=j 
               enddo
c               write(*,*) i,map(i)
             enddo  
c             stop

            ips=index(base,' ')-1

         open(unit=28,file=flst,status='old')

          my_d=1
c          my_var=20*9+2
          if(my_var.ge.n_var) then
           write(*,*) 'variable exceeded ',n_var
           stop
          endif 

1009     read(28,*,end=1010) y0(my_d),(x0(my_d,l),l=1,my_var)
          x0(my_d,n_var)=y0(my_d)
          my_d=my_d+1
         goto 1009 

1010	close(28)

             my_d=my_d-1
             my_d0=my_d
            write(*,*) 'data point ',my_d0 
         endif  ! init
 
          my_data=0
          do my_d=1,my_d0
           if(rn().lt.0.5) then ! use 50%
            my_data=my_data+1
          if(iter.eq.1) then
          y(my_data)=y0(my_d)
          y2(my_data)=y0(my_d)**2
          do l=1,my_var
          x(my_data,l)=x0(my_d,l)
          enddo
          else
          do l=1,my_var
          xinp(l)=x0(my_d,l)
          enddo
           call evaltree_a(1,1,iter,xinp,step,yout2)
          y(my_data)=y0(my_d)-yout2
c          y2(my_d)=y0(my_d)**2  ! this is a bug ? May 17,2013
          y2(my_data)=y(my_d)**2
          do l=1,my_var
          x(my_data,l)=x0(my_d,l)
          enddo
          endif  ! iter
          endif ! rn
         enddo 
        

      if(iup.gt.0) then
          do my_d=1,my_d0
          do l=1,my_var
           xinp(l)=x0(my_d,l)
          enddo
         call evaltree_a(1,1,iter,xinp,step,yout2)
        write(55,*) x0(my_d,n_var),yout2
          enddo
         close(55)
      endif 



        return
        end



c############################################################################
	subroutine tree_cons(my_data,my_var,x,y,y2,
     &   nodlst,nod_num,threshold)
        implicit none
        integer n_dep,n_var,n_data,my_data,my_var,n_nod
        integer i,j,k,l,m,n,l1,l2,l0,j0,id,level
        parameter(n_dep=6,n_data=300,n_var=5000,n_nod=1500,level=2)
        integer nodlst(n_nod,5),nod_num,nod_num0,dat(n_nod,n_data)
     &  ,my_data2,k1,k2,datlst(n_nod),nod_num2
        real*8 y(n_data),x(n_data,n_var),s0,s1,s2,yav1,yav2,yout,
     &  g0,g1,thr,threshold(n_nod,2),x0,x1,x2,yav0,xinp(n_var)
     &  ,y2(n_data),entropy(n_nod),s10,s20,yav10,yav20,xmax,xmin
     &  ,dxx
           if(my_data.le.1) then
             nod_num=0
             return
           endif 
            

           nod_num=1
           yav0=0
           s0=0
           do i=1,my_data
           yav0=yav0+y(i)
           s0=s0+y2(i)
           enddo
           s0=s0-yav0**2/my_data            
           nodlst(nod_num,1)=-1   ! to child 1
           nodlst(nod_num,2)=-1   ! to child 2
           nodlst(nod_num,3)=-1   ! to parent
           nodlst(nod_num,4)=-1  ! point to variable index for split
           nodlst(nod_num,5)=my_data  ! number data point
           threshold(nod_num,1)=0    ! threshold for splitting
           threshold(nod_num,2)=yav0/my_data ! prediction
           entropy(nod_num)=s0    
           do l=1,my_data
           dat(nod_num,l)=l
           enddo 


             nod_num0=1
             nod_num2=1
        do i=1,n_dep
          do id=nod_num0,nod_num2  ! ! travese all leaves
            my_data2=nodlst(id,5)
            if(nodlst(id,1).le.0.and.my_data2.ge.level) then  ! travese all leaves
           s0=entropy(id)

             g0=s0
             j0=-1
            do j=1,my_var ! traverse all variable
              xmin=1d80
              xmax=-1d8
c              do k=2,my_data2    ! travee all split value          
c              k1=dat(id,k-1)
c              k2=dat(id,k)
c              x0=(x(k1,j)+x(k2,j))*0.5
              do k=1,my_data2    ! travee all split value          
              k2=dat(id,k)
              x0=x(k2,j)
              if(x0.lt.xmin) xmin=x0
              if(x0.gt.xmax) xmax=x0
              enddo
              dxx=(xmax-xmin)/100.0
              do k=1,99
              x0=xmin+dxx*k

              yav1=0.0
              yav2=0.0
              s1=0
              s2=0
              l1=0
              l2=0
             
               do l=1,my_data2
                  k2=dat(id,l)
                  if(x(k2,j).lt.x0)  then
                  l1=l1+1
                  yav1=yav1+y(k2)                   
                  s1=s1+y2(k2)
                  else
                  l2=l2+1
                  yav2=yav2+y(k2)
                  s2=s2+y2(k2)
                  endif 
               enddo ! l

                 if(l1.le.0.or.l2.le.0) then
                 g1=1.d8
                 else
                 s1=s1-yav1**2/l1 
                 s2=s2-yav2**2/l2 
                 g1=s1+s2
                 endif  
                 if(g1.lt.g0) then
                 g0=g1
                 j0=j
                 s10=s1
                 s20=s2
                 yav10=yav1/l1
                 yav20=yav2/l2
                 thr=x0
                 endif 
c                 write(*,*) l1,l2,s1+s2,g0,j0,thr,s0

              enddo ! k
 
            enddo  ! j
             
c            write(*,*) g0,j0,thr,s0
           if(g0.lt.(s0-1.d-3)) then
              s0=g0
           nodlst(id,1)=nod_num+1   ! to child 1
           nodlst(id,2)=nod_num+2   ! to child 2
           nodlst(id,4)=j0  ! piont to variable index for split
           threshold(id,1)=thr ! threshold
           

c	child1
           nod_num=nod_num+1
           nodlst(nod_num,1)=-1   ! to child 1
           nodlst(nod_num,2)=-1   ! to child 2
           nodlst(nod_num,3)=id   ! parent
           nodlst(nod_num,4)=-1  ! piont to variable index for split
           threshold(nod_num,1)=0 ! threshold
           threshold(nod_num,2)=yav10
           entropy(nod_num)=s10
           
c	child2
           nod_num=nod_num+1
           nodlst(nod_num,1)=-1   ! to child 1
           nodlst(nod_num,2)=-1  ! to child 2
           nodlst(nod_num,3)=id   ! parent
           nodlst(nod_num,4)=-1  ! piont to variable index for split
           threshold(nod_num,1)=0 ! threshold
           threshold(nod_num,2)=yav20
           entropy(nod_num)=s20


              l1=0
              l2=0
               do l=1,my_data2
                  k2=dat(id,l)
                  if(x(k2,j0).lt.thr)  then
                  l1=l1+1
                  nodlst(nod_num-1,5)=l1
                  dat(nod_num-1,l1)=k2
                  else
                  l2=l2+1
                  nodlst(nod_num,5)=l2
                  dat(nod_num,l2)=k2
                  endif
               enddo ! l

              endif  ! g0
       
           endif ! leaves

          enddo ! id
 
          nod_num0=nod_num2+1
          nod_num2=nod_num


        enddo ! i->n_dep
           if(nod_num.gt.n_nod) then
              write(*,*) 'node number exceeds ',n_nod
              stop
           endif 
c             write(*,*) nod_num,s0
c             do i=1,nod_num
c      write(*,*) i,(nodlst(i,l),l=1,5),threshold(i,1),threshold(i,2)
c             write(*,*) (dat(i,l),l=1,nodlst(i,5))
c             enddo


        return
        end


c############################################################################
	subroutine tree_eval(nodlst,threshold,xinp,yout)
        implicit none
        integer n_dep,n_var,n_data,my_data,my_var,n_nod
        integer i,j,k,l,m,n,l1,l2,l0,j0,id
        parameter(n_dep=6,n_var=5000,n_nod=1500)
        integer nodlst(n_nod,5),nod_num,nod_num0
     &  ,my_data2,k1,k2
        real*8 s0,s1,s2,yav1,yav2,yout,
     &  g0,g1,thr,threshold(n_nod,2),x0,x1,x2,yav0,xinp(n_var)


	  i=1
123	continue
          j0=nodlst(i,4)
          if(j0.gt.0) then
          x0=threshold(i,1)
          x1=xinp(j0)
          if(x1.lt.x0) then
            id=nodlst(i,1)
          else
            id=nodlst(i,2)
          endif 

          else
           goto 124
          endif 
c          write(*,*)i, ' ii'
          i=id 
        goto 123
124	continue
          
          yout=threshold(i,2)
          

        return
	end

c############################################################################
        subroutine tree_eval2(iu,jv,iter,xinp,yout)
        implicit none
        integer n_dep,n_var,n_data,my_data,my_var,n_nod
        integer i,j,k,l,m,n,l1,l2,l0,j0,id,iter,iu,jv,maxit
        parameter(n_dep=6,n_var=5000,n_nod=1500,maxit=2000)
        integer nodlst(n_nod,5),nod_num,nod_num0
     &  ,my_data2,k1,k2
        real*8 s0,s1,s2,yav1,yav2,yout,
     &  g0,g1,thr,threshold(n_nod,2),x0,x1,x2,yav0,xinp(n_var)

        integer mytree(4,4,maxit,n_nod,5),mynodnum(4,4,maxit)
        real*8  mythre(4,4,maxit,n_nod,2)
        common /treedat/mythre,mytree,mynodnum


          yout=0
          if(mynodnum(iu,jv,iter).le.0) return

          i=1
123     continue
          j0=mytree(iu,jv,iter,i,4)
          if(j0.gt.0) then
          x0=mythre(iu,jv,iter,i,1)
          x1=xinp(j0)
          if(x1.lt.x0) then
            id=mytree(iu,jv,iter,i,1)
          else
            id=mytree(iu,jv,iter,i,2)
          endif

          else
           goto 124
          endif
c          write(41,*)i, ' ii'
          i=id
        if(id.gt.0) goto 123
124     continue

          yout=mythre(iu,jv,iter,i,2)


        return
        end

c     ###################################################
         subroutine read_mtx(im,md,title,mtx,fln,base,ips)
        implicit real*8(a-h,o-z)
        parameter(maxres=800)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70
        real*8 mtx(maxres,20),mtx0(20)
        real*8 logist
        integer map2(20),bls(26)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/


      if(fln(1:1).eq.' ') then
           ip=index(title(md),' ')-1
      filen=base(1:ips)//'../mtx/'//title(md)(1:ip)//'.mtx'

c      filen='/net/dell/01/hzhou2/sparks/newmtx/mtx/'//
c     &       title(md)(1:ip)//'.mtx'

      else
      filen=fln
      endif


           num=0
           open(unit=20,file=filen,status='old')

           do i=1,14
           read(20,*)
           enddo

 131       read(20,'(a261)',end=132) whole
           if(whole(1:1).eq.'-') then
           num=num+1
           read(whole(1:200),*) (bls(j),j=1,26)

             do i=1,20
                j=map2(i)

               mtx0(i)=bls(j)*0.01
c               mtx(num,i)=logist(mtx0(i))
c               mtx(num,i)=mtx0(i)*0.5
               mtx(num,i)=mtx0(i)
             enddo
            endif
            goto 131
 132       close(20)
          if(num.ne.im) then
           write(*,*) 'err 2  !! mtx ',title(md)(1:6),' ',num,im,md
           stop
          endif

          return
          end
c     ###################################################
c     #########################################
         subroutine read_npf(im,md,title,mtx,fln,base,ips)
        implicit real*8(a-h,o-z)
        parameter(maxres=800)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70,cres
        real*8 mtx(maxres,20),mtx0(20)
        real*8 logist
        integer map2(20),bls(26)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/


      if(fln(1:1).eq.' ') then
      filen=base(1:ips)//'../npf/'//title(md)(1:5)//'.npf'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../npf/'//title(md)(1:6)//'.npf'
      else
      filen=fln
      endif


           open(unit=20,file=filen,status='old')

           read(20,*) nres
           if(nres.ne.im) then
               write(*,*) '# residue inconsistent ! ',filen
               stop
           endif

          do i=1,nres
           read(20,*) l,cres,m,(mtx(i,j),j=1,20)

c              do j=1,20
c              mtx(i,j)=mtx(i,j)*10.0
c              enddo

c           read(20,*) l,cres,m,(mtx0(j),j=1,20)
c            mtx(i,m)=1.0
          enddo
          return
          end

c     CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCc
         subroutine read_aln2prf(im,md,title,mtx,fln,base,ips,gapp)
        implicit real*8(a-h,o-z)
        parameter(maxres=800,maxseq=300)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70,cres,resmap(20)*1,seq(maxseq,maxres)*1

        real*8 mtx(maxres,20),mtx0(20),gapp(maxres)
        real*8 logist
        integer map2(20),bls(26),kcode(maxres,maxseq)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/

      data resmap/'C','M','F','I','L','V','W','Y','A','G',
     &            'T','S','Q','N','E','D','H','R','K','P'/


      if(fln(1:1).eq.' ') then
      filen=base(1:ips)//'../aln/'//title(md)(1:5)//'.aln'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../aln/'//title(md)(1:6)//'.aln'
      else
      filen=fln
      endif


           open(unit=20,file=filen,status='old')

        read(20,*)nseq_ori,nresseq
        if(nseq_ori .gt.maxseq)nseq_ori=maxseq
        do i=1,nseq_ori
        read(20,1)(seq(i,j),j=1,nresseq)
1       format(50a1)
        end do


       do i=1,nseq_ori
        do j=1,nresseq
                kcode(j,i)=-1
                do ires=1,20
                        if(resmap(ires).eq. seq(i,j))then
                        kcode(j,i)=ires
                        go to 18
                        end if
                        end do
18      continue
        end do
        end do


            nres=nresseq
           if(nres.ne.im) then
               write(*,*) '# residue inconsistent ! ',filen
               stop
           endif

         do i=1,nres     
                gapp(i)=0
                do iseq=1,20
                        mtx(i,iseq)=0.
                end do
                nden=0
                do ic=1,nseq_ori
                        ires=kcode(i,ic)
                if(ires.gt.-1)then
                        nden=nden+1
                        mtx(i,ires)=mtx(i,ires)+1
                else
                        gapp(i)=gapp(i)+1
                end if
                end do
                gapp(i)=gapp(i)/nseq_ori
                do iseq=1,20
                mtx(i,iseq)=mtx(i,iseq)/nden
c                mtx(i,iseq)=mtx(i,iseq)/nseq_ori
                end do
          end do



          return
          end

c     #########################################
        subroutine read_aln2prfe10(im,md,title,mtx,fln,base,ips)
        implicit real*8(a-h,o-z)
        parameter(maxres=800,maxseq=300)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70,cres,resmap(20)*1,seq(maxseq,maxres)*1

        real*8 mtx(maxres,20),mtx0(20)
        real*8 logist
        integer map2(20),bls(26),kcode(maxres,maxseq)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/

      data resmap/'C','M','F','I','L','V','W','Y','A','G',
     &            'T','S','Q','N','E','D','H','R','K','P'/


      if(fln(1:1).eq.' ') then
      filen=base(1:ips)//'../aln-e10/'//title(md)(1:5)//'.aln'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../aln-e10/'//title(md)(1:6)//'.aln'
      else
      filen=fln
      endif


           open(unit=20,file=filen,status='old')

        read(20,*)nseq_ori,nresseq
        if(nseq_ori .gt.maxseq)nseq_ori=maxseq
        do i=1,nseq_ori
        read(20,1)(seq(i,j),j=1,nresseq)
1       format(50a1)
        end do
       do i=1,nseq_ori
        do j=1,nresseq
                kcode(j,i)=-1
                do ires=1,20
                        if(resmap(ires).eq. seq(i,j))then
                        kcode(j,i)=ires
                        go to 18
                        end if
                        end do
18      continue
        end do
        end do


            nres=nresseq
           if(nres.ne.im) then
               write(*,*) '# residue inconsistent ! ',filen
               stop
           endif

         do i=1,nres
                do iseq=1,20
                        mtx(i,iseq)=0.
                end do
                nden=0
                do ic=1,nseq_ori
                        ires=kcode(i,ic)
                if(ires.gt.-1)then
                        nden=nden+1
                        mtx(i,ires)=mtx(i,ires)+1
                end if
                end do
                do iseq=1,20
                mtx(i,iseq)=mtx(i,iseq)/nden
                end do
          end do



          return
          end

c     ############################################
      subroutine read_secstr(npro,isec,filen)
      parameter(ntyp=20,maxres=800,maxp=500)
      integer restyp(maxres),rnum,rnum1,rnum2
     &   ,isec(maxp,maxres),ibase(maxp) 
      real*8 reschg(maxres)
      character whole*80, resmap(20)*1,
     &  rnn*1,filen*10,ctmp*20

            open(unit=30,file=filen,status='old') 
            imd=0
            ibase(1)=0
9           read(30,'(a80)',end=1000,err=126) whole


 10        if(whole(1:1).eq.'>') then
 14            continue
               imd=imd+1
               rnum=0

               do i=1,maxres
               reschg(i)=0.0
               enddo

 15          continue
             do i=1,80
             whole(i:i)='-'
             enddo 
             read(30,'(a80)',end=20,err=126) whole
             if(whole(1:1).eq.'>')   goto 20
           do i=1,80
              read(whole(i:i),'(a1)',err=126) rnn
              if(rnn.eq.' ') goto 103
              isl=ichar(rnn) 
              if(isl.gt.90) isl=isl-32
              rnn=char(isl)
c            write(6,*) ichar('z'),ichar('Z'),' mmm'

            if(rnn.eq.'1') then 
               rnum=rnum+1
            restyp(rnum)=1
            else if(rnn.eq.'2') then
               rnum=rnum+1
            restyp(rnum)=2
            else if(rnn.eq.'3') then
               rnum=rnum+1
            restyp(rnum)=3
            else
c            write(*,*) 'NO type for ', rnn
c            write(*,*) 'check input crd file!'
c            stop 
c            goto 20
            goto 15
            endif

          if(rnum.ge.maxres.or.imd.ge.maxp) then
               write(*,*) 'can not handle sec ',rnum,imd
               stop
          endif
 

 103     enddo


        goto 15


 20        continue

            i0=ibase(imd)
            ibase(imd+1)=i0+rnum
            do i=1,rnum
c            isec(i0+i)=restyp(i)
            isec(imd,i)=restyp(i)
            enddo

c         write(6,*) 

         else 
            goto 9 
         endif  ! whole

        if(whole(1:1).ne.'-')    goto 10

 1000    continue
          npro=imd

          goto 127
 126      write(*,*) 'err here !', imd
                
 127      continue
          close(30)
          return
      end
c     ############################################
	subroutine calprob_1(ffuv,iu,jv,ii,jj,len,prob)
        parameter (maxpr=5,maxalilen=200,maxres=800,maxp=500)

        real*8 ffuv(4,4,maxpr,maxalilen),prob
        real*8 alf(4,0:maxalilen),bet(4,maxalilen)

         do i=1,4
         alf(i,1)=exp(ffuv(4,i,ii,1))
         bet(i,len)=1.0
         enddo 
         alf(4,1)=0.0
         alf(4,0)=1.0
         alf(1,0)=.0
         alf(2,0)=.0
         alf(3,0)=.0
         bet(4,len)=0.0

         do i=2,jj
           yy=0
           do l=1,3
              xx=0
              do m=1,3
              xx=xx+exp(ffuv(m,l,ii,i))*alf(m,i-1)
              enddo
              alf(l,i)=xx
           yy=yy+xx
           enddo
c          yy=3 
          if(i.lt.jj) then
           do l=1,3
              alf(l,i)=alf(l,i)/yy
           enddo
          endif 
         enddo
c            write(*,*) (alf(l,jj),l=1,3),' alf ',jj
            
c           if(jj.eq.1) write(*,*) 'calprob ',alf(1,1),alf(2,1),alf(3,1)

         do i=len-1,jj,-1
            do l=1,3
              xx=0
              do m=1,3
              xx=xx+exp(ffuv(l,m,ii,i))*bet(m,i+1)
              enddo 
              bet(l,i)=xx
            enddo
            yy=0
            do l=1,3
            yy=yy+bet(l,i)
            enddo 
c            yy=3.0
           do l=1,3
              bet(l,i)=bet(l,i)/yy
           enddo
         enddo

c            write(*,*) (bet(l,jj),l=1,3),' bet ',jj

         zz1=0
         zz2=0
         do l=1,3
           zz1=zz1+alf(l,jj)*bet(l,jj)
c           do m=1,3
c           zz2=zz2+alf(l,jj-1)*exp(ffuv(l,m,ii,jj))*bet(m,jj)
c           enddo
         enddo  

c        write(*,*) zz1,zz2,' zzz'
            prob=alf(iu,jj-1)*exp(ffuv(iu,jv,ii,jj))*bet(jv,jj)/zz1
c            prob=alf(iu,jj-1)*exp(ffuv(iu,jv,ii,jj))*bet(jv,jj)/zz2
c          write(*,*) prob,' prob0 ',zz1


        return
        end
c Uniformlu Distributed Random Number Generator 
c Output:
c     Double Precision RN from 0 to 1:
c Input (changed by Han 2/13/92):
c     Iseed --- random seed for initialization
c     the range should be 0<= Iseed <=31328
c
      FUNCTION RAN(ISEED)
      REAL*8 RAN,RAN1
      INTEGER*4 ISEED
      SAVE INIT
      DATA INIT /1/
      IF (INIT.EQ.1) THEN
        INIT=0
        CALL RMARIN(ISEED,23456)
      END IF

  10  CALL RANMAR(RAN1)
      IF (RAN1.LT.1D-16) GOTO 10
      RAN=RAN1
	RETURN
      END

      FUNCTION RN()
      REAL*8 RN,RAN1
      INTEGER*4 ISEED
      COMMON/SEED/ISEED
      SAVE INIT
      DATA INIT /1/
      IF (INIT.EQ.1) THEN
        INIT=0
        CALL RMARIN(ISEED,23456)
      END IF

  10  CALL RANMAR(RAN1)
      IF (RAN1.LT.1D-16) GOTO 10
      RN=RAN1
	RETURN
      END
C	##############################
      SUBROUTINE RANMAR(RVEC)
*     -----------------
* Universal random number generator proposed by Marsaglia and Zaman
* in report FSU-SCRI-87-50
* In this version RVEC is a double precision variable.
      IMPLICIT REAL*8(A-H,O-Z)
      COMMON/ RASET1 / RANU(97),RANC,RANCD,RANCM
      COMMON/ RASET2 / IRANMR,JRANMR
C      SAVE /RASET1/,/RASET2/
      UNI = RANU(IRANMR) - RANU(JRANMR)
      IF(UNI .LT. 0D0) UNI = UNI + 1D0
      RANU(IRANMR) = UNI
      IRANMR = IRANMR - 1
      JRANMR = JRANMR - 1
      IF(IRANMR .EQ. 0) IRANMR = 97
      IF(JRANMR .EQ. 0) JRANMR = 97
      RANC = RANC - RANCD
      IF(RANC .LT. 0D0) RANC = RANC + RANCM
      UNI = UNI - RANC
      IF(UNI .LT. 0D0) UNI = UNI + 1D0
      RVEC = UNI
      END
 
      SUBROUTINE RMARIN(IJ,KL)
*     -----------------
* Initializing routine for RANMAR, must be called before generating
* any pseudorandom numbers with RANMAR. The input values should be in
* the ranges 0<=ij<=31328 ; 0<=kl<=30081
      IMPLICIT REAL*8(A-H,O-Z)
      COMMON/ RASET1 / RANU(97),RANC,RANCD,RANCM
      COMMON/ RASET2 / IRANMR,JRANMR
      SAVE /RASET1/,/RASET2/
* This shows correspondence between the simplified input seeds IJ, KL
* and the original Marsaglia-Zaman seeds I,J,K,L.
* To get the standard values in the Marsaglia-Zaman paper (i=12,j=34
* k=56,l=78) put ij=1802, kl=9373
      I = MOD( IJ/177 , 177 ) + 2
      J = MOD( IJ     , 177 ) + 2
      K = MOD( KL/169 , 178 ) + 1
      L = MOD( KL     , 169 )
      DO 300 II = 1 , 97
        S =  0D0
        T = .5D0
        DO 200 JJ = 1 , 24
          M = MOD( MOD(I*J,179)*K , 179 )
          I = J
          J = K
          K = M
          L = MOD( 53*L+1 , 169 )
          IF(MOD(L*M,64) .GE. 32) S = S + T
          T = .5D0*T
  200   CONTINUE
        RANU(II) = S
  300 CONTINUE
      RANC  =   362436D0 / 16777216D0
      RANCD =  7654321D0 / 16777216D0
      RANCM = 16777213D0 / 16777216D0
      IRANMR = 97
      JRANMR = 33
      END
c       ###################
        subroutine calprob(ffuv,iu,jv,ii,jj,len,prob)
        parameter (maxpr=5,maxalilen=200,maxres=800,maxp=500)

        real*8 ffuv(4,4,maxpr,maxalilen),prob
        real*8 alf(4,0:maxalilen),bet(4,maxalilen)

         prob=ffuv(iu,jv,ii,jj)


        return
        end
c       ######################################
         subroutine read_pat(im,md,title,mtx,fln,base,ips)
        implicit real*8(a-h,o-z)
        parameter(maxres=800)
        character filen*80,whole*280,title(*)*10,fln*30,tmp*30,
     &  base*70
        real*8 mtx(maxres,20),mtx0(20)
        real*8 logist
        integer map2(20),bls(26)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/

      if(fln(1:1).eq.' ') then
      filen=base(1:ips)//'../pat/'//title(md)(1:5)//'.pat'
       if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../pat/'//title(md)(1:6)//'.pat'
      else
      filen=fln
      endif


           open(unit=20,file=filen,status='old')


           read(20,*) tmp,myres
c           if(myres.ne.im) goto 133

         do i=1,myres
        read(20,'(1x,i5,1x,i2,1x,20f8.3)')
     &          itmp,ijt,(mtx(i,j),j=1,20)
         enddo

 132      close(20)
          return

 133      write(*,*) 'err 2!!!!',num,im,md
          stop

          return
          end

c     #########################################
       subroutine read_sec(im,md,title,isec,iseq,fln,base,ips,conf,nat)
        implicit real*8(a-h,o-z)
        parameter(maxres=800)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70,cres*3,resn(20)*3
        integer mtx(maxres),isec(maxres),iseq(maxres)
        real*8 logist,conf(*)
        integer map2(20),bls(26),jsec(4)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/
       data jsec/3,1,-1,2/

      data resn/'CYS','MET','PHE','ILE','LEU','VAL','TRP','TYR',
     &          'ALA','GLY','THR','SER','GLN','ASN','GLU','ASP',
     &          'HIS','ARG','LYS','PRO'/


      if(fln(1:1).eq.' ') then
       if(nat.lt.0.5) then
      filen=base(1:ips)//'../predSEC/'//title(md)(1:5)//'.SEC'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../predSEC/'//title(md)(1:6)//'.SEC'
       else
      filen=base(1:ips)//'../SEC/'//title(md)(1:5)//'.SEC'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../SEC/'//title(md)(1:6)//'.SEC'
       endif
      else
      filen=fln
      endif

         open(unit=20,file=filen,status='old')

           do i1=1,im
             read(20,*) j,cres,k,conf(i1)
             do j=1,20
             if(resn(j).eq.cres) iseq(i1)=j
             enddo
             isec(i1)=jsec(k)
           enddo
           close(20)


          return
         end

c     #########################################
         subroutine read_asa(im,md,title,mtx,fln,base,ips,nn)
        implicit real*8(a-h,o-z)
        parameter(maxres=800)
        character filen*150,whole*280,title(*)*10,fln*30,
     &  base*70,cres*3
        integer mtx(maxres)
        real*8 logist
        integer map2(20),bls(26)
      data map2/4,13,7,10,12,20,21,23,2,8,19,18,
     &         16,14,6,5,9,17,11,15/


      if(fln(1:1).eq.' ') then
       if(nn.lt.0.5) then
      filen=base(1:ips)//'../predasa/'//title(md)(1:5)//'.asa'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../predasa/'//title(md)(1:6)//'.asa'
       else
      filen=base(1:ips)//'../asa/'//title(md)(1:5)//'.asa'
        if(title(md)(6:6).ne.' ')
     &filen=base(1:ips)//'../asa/'//title(md)(1:6)//'.asa'
       endif 
      else
      filen=fln
      endif

           do i1=1,im
           mtx(i1)=2
           enddo
           open(unit=20,file=filen,status='old')
           do i1=1,im
           read(20,*,end=10) l1,cres,xl2,xl3,x4
           if(x4.lt.0.25) mtx(i1)=1
           enddo
10      continue
           close(20)


          return
         end

c	################################
	subroutine matsc(i1,i2,m1,n1,xmat,xo)
        parameter(maxres=800,maxp=500)
        real*8 xmat(maxp,5,maxres,20),xo(*)

                 xx1=0
                 xx2=0
                 xx3=0
                 xx4=0
                 xx5=0
                 xx6=0
                 do l=1,20
                 xx1=xx1+xmat(i1,1,m1,l)*xmat(i2,2,n1,l)  ! mtx(seq)*npf(template)
                 xx2=xx2+xmat(i1,1,m1,l)*xmat(i2,3,n1,l)  ! mtx(seq)*aln(template)
                 xx3=xx3+xmat(i1,1,m1,l)*xmat(i2,4,n1,l)  ! mtx(seq)*aln10(template)
                 xx4=xx4+xmat(i1,3,m1,l)*xmat(i2,1,n1,l)  ! aln(seq)*mtx(template)
                 xx5=xx5+xmat(i1,4,m1,l)*xmat(i2,1,n1,l)  ! aln10(seq)*mtx(template)
                 xx6=xx6+xmat(i1,3,m1,l)*xmat(i2,5,n1,l)  ! aln(seq)*pat(template)
                 enddo

                 xo(1)=xx1
                 xo(2)=xx2
                 xo(3)=xx3
                 xo(4)=xx4
                 xo(5)=xx5
                 xo(6)=xx6
                return
          end
c	###########################
               subroutine    calneff(myprf,nr,eff)
                parameter(maxres=800)
                 real*8 myprf(maxres,20),eff

                c=0
                do i=1,nr
                   do l=1,20
                   if(myprf(i,l).gt.0) then
                   c=c-myprf(i,l)*log(myprf(i,l))
                   endif
                   enddo
                enddo

                eff=exp(c/nr)

               return
               end
c	######################
             subroutine evaltree_a(n1,n2,iter,xinp,step,yout2)
	     parameter(n_var=5000)             
             real*8 xinp(n_var),yout2,yout,step
             xx10=0
             do iter2=1,iter
             call tree_eval2(n1,n2,iter2,xinp,yout)
             xx10=xx10+yout*step
c             write(41,*) yout*step,iter2,xx10
             enddo
             yout2=xx10
             return
             end
c	###################
         subroutine calfeature(iu,jv,ipox1,ipoy1,
     &       mymtx,myprf,myprf1,mysec,iysec,x,y,imx,imy,
     &       umtxb,prflib,prflib1,npflib,secconf,libconf,myasa,libasa,
     &       pat,xinp,gapprfme,gapprflib)   ! null-> M
         implicit real*8(a-h,o-z)
         parameter(maxres=800,ndim=1.4*maxres,n_var=5000,ntyp=20)
         integer mysec(*),iysec(*),x(*),y(*),libasa(*),myasa(*),map(20)
         real*8 mymtx(maxres,20),myprf(maxres,20),myprf1(maxres,20)
     &          ,umtxb(maxres,20),prflib(maxres,20),prflib1(maxres,20)
     &          ,npflib(maxres,20),xinp(*),vsec(3,3),hdp(20)
     &          ,hcut,sdm0(20,20),sdm(20,20)
     &          ,secconf(*),libconf(*),pat(maxres,20)
     &          ,blse(20,20),bls(20,20),eff1,eff2
     &          ,gapprfme(*),gapprflib(*)
         character resmap(20)*1, aaa*20
         data init/0/
c         data vsec/9*0.0/,hdp/20*0.d0/,hcut/0.d0/
        common /ddd0/vsec,hdp,hcut
       data resmap/'C','M','F','I','L','V','W','Y','A','G',
     &            'T','S','Q','N','E','D','H','R','K','P'/
       data aaa/'ARNDCQEGHILKMFPSTWYV'/
c       data map/20*0/,sdm/400*0.0/,blse/400*0.0/
       data map/20*0/
       common /ddd1/sdm,blse


           if(init.eq.0) then
                init=1

            vsec(1,1)=1.0
            vsec(2,2)=1.0
            vsec(3,3)=0.0
            vsec(3,1)=-0.5
            vsec(3,2)=-0.5
            vsec(1,3)=-0.5
            vsec(2,3)=-0.5
            vsec(1,2)=-1
            vsec(2,1)=-1
            do i=1,20
               do j=1,20
               if(aaa(i:i).eq.resmap(j)) map(i)=j
               enddo
            enddo

        open(unit=20,file='/gpfs1/u/hzhou2/data/for/CC80.txt',
     &               status='old')
        open(unit=21,file='/gpfs1/u/hzhou2/data/for/SDM.txt',
     &               status='old')

        read(20,*)
        read(20,*)
        read(20,*)
        read(20,*)
        read(20,*)
        read(21,*)
        do i=1,ntyp
        read(20,*) (bls(i,j),j=1,ntyp)
        read(21,*) (sdm0(i,j),j=i,ntyp)
            do k=1,i
               sdm0(i,k)=sdm0(k,i)
            enddo
        enddo
        close(20)
        close(21)



         do i=1,ntyp
         do j=1,ntyp
         blse(map(i),map(j))=bls(i,j)
         sdm(map(i),map(j))=sdm0(i,j)
         enddo
         enddo



c       hydropathy parameters
c            open(unit=29,file='packability.dat',status='old')
            open(unit=29,file='scale.dat',status='old')
            do i=1,20
            read(29,*) tmp
c            hdp(i)=100.0*tmp
            hdp(i)=tmp
            enddo
            close(29)
          endif 

                 call calneff(myprf,imx,eff1)
                 call calneff(prflib,imy,eff2)


c          hcut=1.1d0
          hcut=0.d0

c	iu ( at ipox,ipoy: II-1)
c	jv ( at ipox1,ipoy1: II )
         do l=1,n_var
           xinp(l)=0
         enddo

        if(jv.eq.1) then   ! M state
           xx1=0 
           xx2=0 
           xx3=0 
           xx4=0 
           xx5=0 
           xx6=0 
           do l=1,20
           xx1=xx1+mymtx(ipox1,l)*npflib(ipoy1,l)
           xx2=xx2+mymtx(ipox1,l)*prflib(ipoy1,l)
           xx3=xx3+mymtx(ipox1,l)*prflib1(ipoy1,l)
           xx4=xx4+myprf(ipox1,l)*umtxb(ipoy1,l)
           xx5=xx5+myprf1(ipox1,l)*umtxb(ipoy1,l)
           xx6=xx6+myprf(ipox1,l)*pat(ipoy1,l)
           enddo 
           xinp(1)=xx1
           xinp(2)=xx2
           xinp(3)=xx3
           xinp(4)=xx4
           xinp(5)=xx5
           xinp(6)=xx6
           xinp(7)=abs(hdp(x(ipox1))-hdp(y(ipoy1)))
           xinp(8)=vsec(mysec(ipox1),iysec(ipoy1))*secconf(ipox1)
           xinp(9)=vsec(myasa(ipox1),libasa(ipoy1))

                 xx1=0
                 xx2=0
                 do l1=1,20
                   do l2=1,20
                 xx1=xx1+myprf(ipox1,l1)*blse(l1,l2)*prflib(ipoy1,l2)
                 xx2=xx2+myprf(ipox1,l1)*sdm(l1,l2)*prflib(ipoy1,l2)
                   enddo
                 enddo
                 xinp(10)=eff1
                 xinp(11)=eff2
                 xinp(12)=xx1
                 xinp(13)=xx2


        elseif(jv.eq.2) then   ! I_s state
           xinp(iysec(ipoy1))=1
           xinp(3+libasa(ipoy1))=1
c            do l=1,20
c             xinp(5+l)=prflib(ipoy1,l)
c            enddo
             xinp(5+y(ipoy1))=1.0
                   nc=0
                  do l=-2,2
                      l2=l+ipoy1
                      if(l2.gt.0.and.l2.le.imy.and.
     &               hdp(y(l2)).lt.hcut) then
c     &                libasa(l2).lt.2) then
                     nc=nc+1
                      endif
                  enddo
c                  xinp(26)=nc
c                  xinp(27)=gapprflib(ipoy1)
                   xinp(26+nc)=1.0
                   xinp(32)=gapprflib(ipoy1)
c                  xx1=1
c                  do l=1,20
c                  xx1=xx1-prflib(ipoy1,l)
c                  enddo
c                  xinp(27)=xx1


        elseif(jv.eq.3) then
           xinp(mysec(ipox1))=1
           xinp(3+myasa(ipox1))=1
c            do l=1,20
c             xinp(5+l)=myprf(ipox1,l)
c            enddo
             xinp(5+x(ipox1))=1.0

                   nc=0
                  do l=-2,2
                      l2=l+ipox1
                      if(l2.gt.0.and.l2.le.imx.and.
     &        hdp(x(l2)).lt.hcut) then
c     &         myasa(l2).lt.2) then
                      nc=nc+1
                      endif
                  enddo    
c                  xinp(26)=nc
c                  xinp(27)=gapprfme(ipox1)
                   xinp(26+nc)=1.0
                   xinp(32)=gapprfme(ipox1)
c                  xx1=1
c                  do l=1,20
c                  xx1=xx1-myprf(ipox1,l)
c                  enddo
c                  xinp(27)=xx1



          endif 
          


         return
         end

c      ###############################################
