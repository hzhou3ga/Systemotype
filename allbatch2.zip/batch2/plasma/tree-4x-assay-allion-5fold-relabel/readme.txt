to run training and test:

run training set
1 ./train_permuted.job 

run test set
2. ./test_permuted.job

3. build cutoff mapping 
(m=2, delta=0.05):
./train_permuted_kn_2.job

(m=3, delta=0.05):
./train_permuted_kn_3.job

(m=4, delta=0.05):
./train_permuted_kn_4.job

(m=5, delta=0.05):
./train_permuted_kn_5.job

(m=5, delta=0.01):
./train_permuted_kn_8.job

(m=5, delta=0.001):
./train_permuted_kn_7.job


4. get result for test set:
(m=2, delta=0.05):
./test_permuted_kn_2.job > test2.out

(m=3, delta=0.05):
./test_permuted_kn_3.job > test3.out

(m=4, delta=0.05):
./test_permuted_kn_4.job > test4.out

(m=5, delta=0.05):
./test_permuted_kn_5.job > test5.out 

(m=5, delta=0.01):
./test_permuted_kn_8.job > test8.out 

(m=5, delta=0.001):
./test_permuted_kn_7.job > test7.out

test*.out explained (symbol "#" not counted as column) :
column 1: permutation round #
       2: mean # of corrected positives (in test set, "mean" is the mean value of the 5 test sets for each permutation)
       3: mean total # of positives 
       4: mean recall rate
       5: mean false positives
       6: mean total negatives
       7: mean false postive rate 

     reported in paper are the means of all permutation's mean values
       

