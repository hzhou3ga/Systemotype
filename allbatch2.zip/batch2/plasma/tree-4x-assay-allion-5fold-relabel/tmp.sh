#!/bin/bash

x1="xxx"

if [ ! -z "$x1" ]; then
echo $x1
fi
