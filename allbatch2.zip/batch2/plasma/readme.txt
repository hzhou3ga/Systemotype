see tree-4x-assay-allion-5fold-relabel/readme.txt 
