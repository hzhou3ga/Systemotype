see tree-4x-assay-allion-5fold/readme.txt 
