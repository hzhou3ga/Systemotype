./scan_u_z.job feature_file
feature_file:  sample_fea.txt or not normalized:
